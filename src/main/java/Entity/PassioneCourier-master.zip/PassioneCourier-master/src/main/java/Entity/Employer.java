package Entity;

public class Employer {
}
